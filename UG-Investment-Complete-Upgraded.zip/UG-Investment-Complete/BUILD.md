# Production build checklist

1. Deploy `server/` to a Node.js host with persistent disk for SQLite, or migrate the database to PostgreSQL.
2. Configure environment variables from `.env.example`.
3. Use a long random `JWT_SECRET`.
4. Set `ADMIN_PASSWORD` privately; never put it in the mobile source.
5. Put the API behind HTTPS.
6. Change `API` in `mobile/App.js` from `http://YOUR_SERVER_IP:4000` to your HTTPS API URL.
7. In `mobile/`, install dependencies and run `npx expo start` for testing.
8. For installable builds, configure Expo/EAS credentials and run `eas build -p android` and `eas build -p ios`.
9. Before accepting real money, complete payment-provider integration, legal/compliance review, audit logging, rate limiting, backups, and production database migration.

# UG Investment — Complete Working Version

This project contains the upgraded Expo mobile app and Express/SQLite API.

## Included
- User registration/login
- One protected admin account
- UGX balances
- Deposit requests to receiving account `0785700754`
- Admin deposit approval/rejection
- Investment plans and admin approval
- Withdrawals with mobile-money/account details and admin approval/rejection
- Transaction and investment history
- Admin user list and manual balance credit
- SQLite persistence
- JWT authentication and bcrypt password hashing

## Important
This version uses **manual payment verification**. It does not claim to transfer real money automatically. To automate Mobile Money payments, connect a licensed payment provider/API and implement server-side callbacks/webhooks.

## Configure
Copy `server/.env.example` to `.env` and set a strong `JWT_SECRET` and a private `ADMIN_PASSWORD` before deployment.

Set the mobile app `API` constant in `mobile/App.js` to the HTTPS URL of the deployed API.

## Run API
```bash
cd server
npm install
npm start
```

## Run mobile app
```bash
cd mobile
npm install
npx expo start
```

For production, use an HTTPS backend and build Android/iOS with EAS Build.
